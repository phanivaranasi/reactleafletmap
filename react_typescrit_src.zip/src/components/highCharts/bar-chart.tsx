import * as React from 'react';
 
const BarChart: React.FunctionComponent = () => {
 
    return (
       <div>
           <h5>Bar-chart Works!</h5>
       </div>
    )
 
}

export default BarChart;


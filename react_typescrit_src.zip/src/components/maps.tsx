import * as React from "react";
import * as leaf from 'leaflet';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';

// declare var require: any;
// declare let L: any;
// require('leaflet-routing-machine');



export default class MapsComp extends React.Component<{}, {}> {

    constructor(props: any) {
        super(props);
    }

    componentDidMount() {
        // var mymap = leaf.map('mapid').setView([-31.2532, 146.9211], 7);
        // leaf.tileLayer('http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        //     subdomains: ['a', 'b', 'c']
        // }).addTo(mymap);
    }


    render() {

        return (
            <div>
                {/* <div id="mapid" style={{ width: '100% !important' }}></div> */}
                <MapContainer center={[51.505, -0.09]} zoom={13} scrollWheelZoom={false}>
                    <TileLayer
                        attribution='&copy; <a href="http://osm.org/copyright">OpenStreetMap</a> contributors'
                        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                    />
                    <Marker position={[51.505, -0.09]}>
                        <Popup>
                            A pretty CSS3 popup. <br /> Easily customizable.
    </Popup>
                    </Marker>
                </MapContainer>
            </div >
        )
    }
}